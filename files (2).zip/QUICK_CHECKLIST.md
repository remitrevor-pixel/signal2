# SIGNAL Console — Quick Checklist (Windows)

**Print this out or keep it open while you work.**

## ☐ Phase 1: Upload Code (GitHub)
- [ ] Go to **https://github.com/signup** → create account
- [ ] Verify your email
- [ ] Click **+** → **New repository** → name it `signal-console`
- [ ] Click **Add file** → **Upload files**
- [ ] Drag all `signal-console` files into the upload area
- [ ] Click **Commit changes**

## ☐ Phase 2: Deploy Backend (Render)
- [ ] Go to **https://render.com/register** → sign up with GitHub
- [ ] Click **+ New** → **Web Service**
- [ ] Select your `signal-console` repo
- [ ] Set **Plan** to **Free**
- [ ] Click **Create Web Service** → **wait for "live"**
- [ ] Copy the URL (looks like `https://signal-console-backend-xxxx.onrender.com`)
- [ ] Click **Environment** tab
- [ ] Add your API keys (SERPER_API_KEY, REDDIT_CLIENT_ID, etc.)

## ☐ Phase 3: Install Tools on Windows
- [ ] Install Node.js: **https://nodejs.org** (LTS) → run installer
- [ ] Install Java: **https://oracle.com/java/technologies/downloads** → download Windows x64 → run installer
- [ ] Install Android SDK: download from **https://developer.android.com/studio/command-line-tools** → extract to `C:\Android\cmdline-tools`
- [ ] Open Command Prompt and run:
  ```
  setx ANDROID_HOME C:\Android
  setx JAVA_HOME "C:\Program Files\Java\jdk-22"
  ```

## ☐ Phase 4: Build APK
- [ ] Open Command Prompt
- [ ] Navigate to your `signal-console` folder: `cd Desktop\signal-console`
- [ ] Run:
  ```
  npm install -g @capacitor/cli
  npm install
  npm install @capacitor/core @capacitor/cli @capacitor/android @capacitor/browser
  npx cap init
  ```
  - App name: `Signal Console`
  - App ID: `com.signal.research`
  - Web dir: `public`
- [ ] Run: `npx cap add android`
- [ ] Open `capacitor.config.json` in Notepad
- [ ] Add your Render URL to the `server` section:
  ```json
  "server": {
    "url": "https://signal-console-backend-xxxx.onrender.com",
    "cleartext": true
  }
  ```
- [ ] Save and run: `npx cap sync android`
- [ ] Run: `npx cap build android --keystorepath ./my-release-key.jks --keystorePassword password --keystoreAlias my-key-alias --keystoreAliasPassword password`
- [ ] **Wait 5–10 minutes** for the build to finish

## ☐ Phase 5: Install on Phone
- [ ] Find the APK at: `android/app/release/app-release.apk`
- [ ] Copy to your phone (email, USB, etc.)
- [ ] On phone: **Settings** → enable **Install from unknown sources**
- [ ] Open the APK file → **Install**
- [ ] Open the Signal app

## ✓ Done!
- [ ] Type in search bar → hit Search
- [ ] If you see results, it's working!
- [ ] If "backend not reachable," check your Render URL in `capacitor.config.json`

**Stuck? Tell me the step number and what you see on screen.**
