# SIGNAL Console — Beginner Walkthrough (Windows)

This guide walks you through **every single step** to get your APK built and running. Estimated time: 1–2 hours total (mostly waiting for downloads and builds).

---

## Part 1: GitHub Setup (10 minutes)

GitHub is where you'll upload your code so Render can access it.

### Step 1.1: Create a GitHub Account

1. Open your web browser
2. Go to: **https://github.com/signup**
3. Fill in:
   - **Username**: pick any name (e.g., `signal-research-app`)
   - **Email**: your real email
   - **Password**: something secure
4. Click the blue **Create account** button
5. GitHub will send you an email to verify — **check your email and click the verification link**
6. When you're done: you should see a screen that says "Welcome to GitHub"

### Step 1.2: Create a New Repository

1. While logged into GitHub, click the **+** icon in the top-right corner (next to your profile picture)
2. Click **New repository**
3. Fill in:
   - **Repository name**: `signal-console` (this is just a label — any name works, but keep it simple)
   - **Description** (optional): `Cross-platform research search console`
   - **Public** (selected by default) ← keep this
4. Click the blue **Create repository** button
5. You'll see a page with a lot of instructions — **ignore all of that** and scroll to find the section that says "uploading an existing project"

### Step 1.3: Upload Your Code to GitHub (via Web)

This is the easiest way if you're on Windows and have never used Git.

1. In GitHub, look for a button that says **"Add file"** (top right area, or sometimes it's a dropdown with a code icon)
2. Click **Add file** → **Upload files**
3. You'll see a drag-and-drop area that says "Drag files here to add them to your repository"
4. **Open your file explorer** on Windows (Win key + E)
5. Navigate to wherever you downloaded/unzipped `signal-console`
6. **Open that folder** so you see all the files inside (`package.json`, `public/`, `server/`, `discord-bot/`, etc.)
7. **Select all the files inside** (Ctrl+A)
8. **Drag them into the GitHub upload area** in your web browser
9. Wait for them to upload (it'll show a progress bar)
10. Scroll down and click the green **Commit changes** button
11. Done — your code is now on GitHub

---

## Part 2: Render Deployment (15 minutes)

Render will host your backend so the APK can reach it from anywhere.

### Step 2.1: Create a Render Account

1. Open a new browser tab
2. Go to: **https://render.com/register**
3. Click **Sign up with GitHub** (easiest option)
4. GitHub will ask "Do you want to authorize Render?" — click **Authorize render**
5. You're now logged into Render

### Step 2.2: Deploy Your Backend

1. In Render, click the **+ New** button (top left area)
2. Click **Web Service**
3. Under "Connect a repository," you should see `signal-console` listed (if not, click "Configure account" and authorize GitHub again)
4. Click **signal-console** to select it
5. Fill in the form:
   - **Name**: `signal-console-backend` (can be anything)
   - **Environment**: `Node`
   - **Build Command**: leave as `npm install`
   - **Start Command**: leave as `npm start`
   - **Plan**: click the dropdown and select **Free** (this is important — don't pick paid!)
6. Click the blue **Create Web Service** button
7. Render will now build and deploy — you'll see a logs window. **Wait for it to say "Your service is live"** (this takes 2–5 minutes)
8. Once it says "live," look at the top of the page — you'll see a URL like `https://signal-console-backend-xxxx.onrender.com` — **copy this URL and save it somewhere** (paste it into Notepad for now)

### Step 2.3: Add Your API Keys to Render

1. While still on the Render service page, click the **Environment** tab (top area)
2. You'll see a section that says "Environment Variables" — click **Add Environment Variable**
3. For each key below, add it one at a time:
   - **Variable name**: `SERPER_API_KEY`
   - **Value**: paste your actual Serper API key here
   - Click **Save**
4. Repeat for these (if you have them; leave blank if you don't):
   - `SERPER_API_KEY` (your Serper key)
   - `FIRECRAWL_API_KEY` (your Firecrawl key, if you have one)
   - `SCRAPERAPI_API_KEY` (your ScraperAPI key, if you have one)
   - `REDDIT_CLIENT_ID` (your Reddit app client ID, if you set one up)
   - `REDDIT_CLIENT_SECRET` (your Reddit app secret, if you set one up)

5. Once you've added all your keys, click **Save** (there's usually a Save button at the bottom)
6. Render will restart — wait for it to say "live" again

**Your backend is now live at that URL you saved.**

---

## Part 3: Windows Setup for APK Building (20 minutes)

You need Node.js and Android SDK on your computer to build the APK.

### Step 3.1: Install Node.js (Windows)

1. Open your browser
2. Go to: **https://nodejs.org**
3. You'll see two download buttons — click the **LTS** (Long Term Support) version
4. It will download a `.msi` file
5. **Open your Downloads folder** (usually at `C:\Users\[YourUsername]\Downloads`)
6. **Double-click the Node.js installer** (it'll be named something like `node-vXX.X.X.msi`)
7. A window will pop up asking to install — click **Next** a few times, then **Install**, then **Finish**
8. **Close and reopen** any terminal/command-prompt windows you have open (so they pick up the new Node installation)

**To verify Node is installed:**
1. Press **Win + R** on your keyboard
2. Type `cmd` and press Enter (this opens Command Prompt)
3. Type: `node --version` and press Enter
4. It should print a version number like `v20.X.X` — if it does, Node is installed correctly

### Step 3.2: Install Java (Required for Android)

1. Open your browser
2. Go to: **https://www.oracle.com/java/technologies/downloads/**
3. Look for **Java SE Development Kit (JDK)** — click the download for **Windows x64**
4. You may need to click "Accept License" first
5. Download the `.exe` file
6. **Double-click it** and follow the installer (click Next, Install, Finish)

### Step 3.3: Install Android SDK (Command-Line Tools)

This is the trickiest part, but I'll walk you through it exactly.

1. Go to: **https://developer.android.com/studio/command-line-tools**
2. Scroll down to **Command-line tools** and click **Download** (it's a `.zip` file)
3. In your Downloads folder, **right-click the zip file** → **Extract All** → **Extract**
4. You'll get a folder called `cmdline-tools`
5. **Create a new folder** on your computer. I recommend: `C:\Android\cmdline-tools`
   - Press Win + R, type `cmd`, press Enter
   - Copy and paste this command:
     ```
     mkdir C:\Android\cmdline-tools
     ```
   - Press Enter
6. **Move the extracted `cmdline-tools` folder** into `C:\Android\cmdline-tools`
   - In File Explorer, go to your Downloads folder
   - Find the `cmdline-tools` folder
   - Right-click → Cut
   - Navigate to `C:\Android`
   - Right-click → Paste

7. Now you need to set up environment variables. **Press Win + R**, type `cmd`, press Enter, and run these commands one at a time:

   ```
   setx ANDROID_HOME C:\Android
   ```

   ```
   setx JAVA_HOME "C:\Program Files\Java\jdk-22"
   ```

   (Note: if your Java folder is named differently, adjust the path — go to `C:\Program Files\Java` in File Explorer to see the exact name)

8. **Close and reopen** Command Prompt (so it picks up the new environment variables)

---

## Part 4: Build Your APK (30 minutes)

Now you'll use Capacitor to build the actual APK.

### Step 4.1: Install Capacitor Globally

1. **Open Command Prompt** (Win + R, type `cmd`, press Enter)
2. Copy and paste this command:
   ```
   npm install -g @capacitor/cli
   ```
3. Press Enter and wait for it to finish

### Step 4.2: Set Up Your Project for Capacitor

1. In Command Prompt, navigate to your `signal-console` folder. If it's on your Desktop, type:
   ```
   cd Desktop\signal-console
   ```
   (or wherever you saved it)

2. Install the project dependencies:
   ```
   npm install
   ```
   (This will take 2–5 minutes)

3. Install Capacitor and the necessary packages:
   ```
   npm install @capacitor/core @capacitor/cli @capacitor/android @capacitor/browser
   ```

4. Initialize Capacitor:
   ```
   npx cap init
   ```
   - When it asks for **App name**: type `Signal Console`
   - When it asks for **App ID**: type `com.signal.research`
   - When it asks for **Web dir**: type `public`
   - Press Enter

5. Add Android as a platform:
   ```
   npx cap add android
   ```
   (This will take a few minutes and create an `android` folder)

### Step 4.3: Update Your Backend URL in the Config

The app needs to know where your Render backend is.

1. Open the file `capacitor.config.json` in a text editor (Notepad is fine)
2. Find the line that looks like:
   ```
   "server": {
   ```
3. Inside that block, add this line (replace the URL with the one you saved from Render):
   ```
   "url": "https://signal-console-backend-xxxx.onrender.com"
   ```
   (So the full block looks like:)
   ```json
   "server": {
     "url": "https://signal-console-backend-xxxx.onrender.com",
     "cleartext": true
   }
   ```
4. Save the file

5. Back in Command Prompt, copy your updated config to Android:
   ```
   npx cap sync android
   ```

### Step 4.4: Build the APK

1. In Command Prompt, type:
   ```
   npx cap build android --keystorepath ./my-release-key.jks --keystorePassword password --keystoreAlias my-key-alias --keystoreAliasPassword password
   ```

2. Capacitor will ask you some questions — just press Enter for each one (it'll create a default signing key)

3. **Wait** — this takes 5–10 minutes. You'll see a progress bar.

4. When it finishes, you'll see a message saying where your APK is. It's usually at:
   ```
   android/app/release/app-release.apk
   ```

5. **Copy this file to your phone** — you can either:
   - Email it to yourself and download it on your phone, or
   - Plug your phone into your computer via USB and copy it directly

### Step 4.5: Install on Your Phone

1. On your phone, go to **Settings** → **Apps** (or **Application Manager**)
2. Find an option for **Unknown apps** or **Install from unknown sources** — toggle it ON (this lets you install apps not from the Play Store)
3. Using your phone's file manager, find the `app-release.apk` file
4. Tap it — your phone will ask "Install this app?" — tap **Install**
5. Once it's done, you should see a **Signal** app on your home screen

### Step 4.6: First Run

1. Open the Signal app
2. **First load will be slow** (your Render backend is waking up from sleep) — wait 30–60 seconds
3. Once it loads, **make sure you can see the search bar and buttons**
4. Try a test search: type `test` and hit Search
5. If you see results, **it's working!** If you see "backend not reachable," your Render URL might be wrong — go back and double-check it in `capacitor.config.json`

---

## Troubleshooting

### "Command not found: node"
- You installed Node but Command Prompt was open before the install — **close and reopen Command Prompt**

### "Command not found: npx"
- Same issue — close and reopen Command Prompt

### "Backend not reachable" in the app
- Check that your Render URL is correct in `capacitor.config.json`
- Make sure Render service says "live" (not in failed/error state)
- Try loading the Render URL directly in your phone's browser to test

### APK build fails
- Make sure you have Android SDK installed and the environment variables are set
- Try running `npx cap sync android` again before rebuilding

### Phone won't install the APK
- Make sure "Unknown apps" is enabled in Settings
- Try a different USB cable or email method

---

## Next Steps

Once it's working:
1. **Add your API keys** to Render (Part 2.3 above)
2. **Sign in** to Reddit/X/etc. via Settings to unlock more features
3. **Save keywords** you use frequently (bookmark icon in search bar)

---

## Questions?

If any step gets stuck, **stop and tell me exactly:**
- What step number you're on
- What you see on screen
- Any error message (copy-paste it exactly)

I'll help you fix it.
